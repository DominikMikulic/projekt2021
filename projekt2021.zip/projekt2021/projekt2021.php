<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"  integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="css2021.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <nav>
    <ul>
      <li><a class="active" href="projekt2021.php">Ocjenjivanje whey proizvoda</a></li>
      <li class="vrste_whey">
        <a href="#" class="naslov1">Vrste whey proteina</a>
        <ul class="marke_whey_popis">
            <li><a href="https://www.grandecig.com/blog/what-is-whey-protein-concentrate">Whey protein concentrate</a></li>
            <li><a href="https://www.healthkart.com/connect/5-whey-protein-isolate-benefits-you-must-know-about/bid-6684">Whey protein isolate</a></li>
            <li><a href="https://www.bodybuilding.com/fun/muscle-up-the-smart-whey-expert-guide-whey-protein-hydrolysate.html">Whey protein hydrolysate</a></li>
        </ul>
      </li>
      <li class="marke_whey">
        <a href="#" class="naslov2">Marke whey proteina</a>
        <ul class="marka">
            <li><a href="https://www.myprotein.co.in/sports-nutrition/impact-whey-protein/11654605.html#:~:text=Created%20with%20premium%20whey%2C%20it's,from%20a%20high%2Dquality%20source.&text=With%20just%201.9g%20of,support%20all%20your%20training%20goals."><img src="impactwhey.jpg" class="whey">Impact whey protein</a></li>
            <li><a href="https://www.optimumnutrition.com/en-gb/Products/Protein/Shakes-%26-Powders/Gold-Standard-100%25-Whey-Protein/p/gold-standard-100-whey-protein"><img src="onwhey.jpg" class="whey"><br>Gold standard whey protein</a></li>
            <li><a href="https://polleosport.hr/platinum-hydro-whey-1590-g-milk-chocolate"><img src="hwhey.jpg" class="whey">Platinum Hydro Whey</a></li>
        </ul>
      </li>
    </ul>
  </nav>


  <?php
 
    if (isset($_POST['spremi'])) {
        $whey_marke = $_POST['whey_marke'];
        $rating = $_POST['rating'];
        $komentar = $_POST['komentar'];
        $spol = $_POST['spol'];
        $opcija = $_POST['opcija']; 

        $result = '';
        $result .= "<Whey>\n";
        $result .= '    <ImeWheya>' . $whey_marke . "</ImeWheya>\n";
        $result .= '    <rating>' . $rating . "</rating>\n";
        $result .= '    <komentar>' . $komentar . "</komentar>\n";
        $result .= '    <spol>' . $spol . "</spol>\n";
        $result .= '    <opcija>' . $opcija . "</opcija>\n";
        $result .= '</Whey>';
        $filename = 'whey' . '.xml';
        file_put_contents($filename, $result);
        die('Uspješno generiran XML!');
 
    }
?>

<div class="forma1">
    <form action="projekt2021.php" method="POST">		
                <label for="vrstawheya">Vrste wheya:</label>
                <select class="izbor" name="whey_marke" id="whey_marke">
                            <option value="Impact Whey Protein">Impact Whey Protein</option>
                            <option value="100% Whey Gold Standard">100% Whey Gold Standard</option>
                            <option value="Platinum Hydro Whey">Platinum Hydro Whey</option>
                            
                        </select><br><br>
                        Ocjena:
                 <fieldset class="rating">
                    <input name="rating" type="radio" id="rating5" value="5" on="change:rating.submit">
                    <label for="rating5" title="5 stars">☆</label>

                    <input name="rating" type="radio" id="rating4" value="4" on="change:rating.submit">
                    <label for="rating4" title="4 stars">☆</label>

                    <input name="rating" type="radio" id="rating3" value="3" on="change:rating.submit"  checked="checked">
                    <label for="rating3" title="3 stars">☆</label>

                    <input name="rating" type="radio" id="rating2" value="2" on="change:rating.submit">
                    <label for="rating2" title="2 stars">☆</label>

                    <input name="rating" type="radio" id="rating1" value="1" on="change:rating.submit">
                    <label for="rating1" title="1 stars">☆</label>
                </fieldset>

                <label for="komentar">Komentar: </label><br>
                <textarea name="komentar"></textarea><br /><br />			
                <p>Spol: </p>
                <label>
                <input type="radio" name="spol" value="musko"/>Muško
                </label><br />
                <label>
                <input type="radio" name="spol" value="zensko" />Žensko
                </label><br /><br><br>

                <p>Dosadašnje iskustvo s whey proteinima:</p>
                <label>
                    <input type="checkbox" value="Prvi put probavam whey protein" name="opcija" />Prvi put probavam whey protein
                </label><br/>
                <label>
                    <input type="checkbox"   value="Probao sam nekoliko različitih vrsta wheya " name="opcija"/>Probao sam nekoliko različitih vrsta wheya 
                </label><br/>
                <label>
                    <input type="checkbox" value="Već par godina kupujem whey" name="opcija"/>Već nekoliko godina kupujem whey
                </label><br/> <br><br><br>

                <input class="form-check-input" type="checkbox" value="" id="spremi"  name="spremi">
                        <label class="spremi" for="spremi">
                            Želim spremiti kao XML<br>
                        </label>

                
                <br>
                <input type="submit" value="Pošalji" />	
            </form>
</div>

</html>

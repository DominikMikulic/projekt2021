Upute za pokretanje projekta
imate i video objašnjenje pa možete paralelno pratiti obje varijante
1.Kako bi pokrenuli projekt morate instalirati XAMPP
preuzmite ga sa 
https://www.apachefriends.org/download.html
2.Ako imate Baze podataka kao predmet onda morate privremeno stopirati Mysql80 proces te kada završite s pregledavanjem
 ponovno možete pokrenuti
3. Kliknite na Apache Start i MySQL Start
4. Pronađite gdje se nalazi folder gdje je instaliran xampp (defaul je C:\xampp)
5. Otvorite "xampp" folder i unutar njega otvorite "htdocs" folder (C:\xampp\htdocs)
6. Unutar "htdocs" foldera kopirajte sav sadržaj koji ste preuzeli, unzipajte ga prije (na datoteku koju ste preuzeli projekt2021)
7. Nakon toga otvorite web pretraživač i u adresnu traku unesite https://localhost/projekt2021/projekt2021.php
8. Ako imate bilo kakvo pitanje pošaljite poruku na dmikulic@tvz.hr

